//= require ./materialize/initial
//= require ./materialize/jquery.easing.1.3
//= require ./materialize/animation
//= require ./materialize/velocity.min
//= require ./materialize/hammer.min
//= require ./materialize/jquery.hammer
//= require ./materialize/global
//= require ./materialize/dropdown
//= require ./materialize/leanModal
//= require ./materialize/materialbox
//= require ./materialize/parallax
//= require ./materialize/tabs
//= require ./materialize/tooltip
//= require ./materialize/waves
//= require ./materialize/toasts
//= require ./materialize/sideNav
//= require ./materialize/scrollspy
//= require ./materialize/forms
//= require ./materialize/slider
//= require ./materialize/cards
//= require ./materialize/chips
//= require ./materialize/pushpin
//= require ./materialize/buttons
//= require ./materialize/transitions
//= require ./materialize/scrollFire
//= require ./materialize/date_picker/picker
//= require ./materialize/date_picker/picker.date
//= require ./materialize/character_counter
//= require ./materialize/carousel.js



